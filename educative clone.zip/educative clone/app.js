const express = require('express')
const bodyparser = require('body-parser')
const request = require("request");
const https = require("https")
const ejs = require('ejs')
const mongoose = require('mongoose')
mongoose.connect("mongodb://localhost:27017/users_java", { useNewUrlParser: true })

const cardSchema = new mongoose.Schema({
    topic: String,
    cardoverview: String,
    courseheading: String,
    courseoverview: String,
    coursecontenttopic: String,
    coursecontentsubtopic: String
});

const cardData = mongoose.model("cardData", cardSchema)

const data1 = new cardData({
    topic: "AWS",
    cardoverview: "How are you",
    courseheading: "How are you",
    courseoverview: "How are you",
    coursecontenttopic: "How are you",
    coursecontentsubtopic: "How are you"
})
const data2 = new cardData({
    topic: "cloud",
    cardoverview: "How are you",
    courseheading: "How are you",
    courseoverview: "How are you",
    coursecontenttopic: "How are you",
    coursecontentsubtopic: "How are you"
})

const app = express();
app.set('view engine', 'ejs')
app.use(express.static(__dirname + '/public/'));
app.use(bodyparser.urlencoded({ extended: true }))
const defaultcard = [data1, data2]


app.get("/", function(req, res) {

    cardData.find({}, function(err, cardsdata) {
        res.render("index", {
            posts: cardsdata
        });
    });
});



app.get("/aman", function(req, res) {
    res.render("aman")
})

app.post("/aman.ejs", function(req, res) {
    const cardTopic = req.body.cardtopic
    const cardOverview = req.body.cardover

    const data = new cardData({
        topic: cardTopic,
        cardoverview: cardOverview
    })
    data.save()

    res.redirect("/")

})

app.get("/posts/:postId", function(req, res) {

    const requestedPostId = req.params.postId;

    cardData.findOne({ _id: requestedPostId }, function(err, post) {
        res.render("xyz", {
            omdata: post,
            heading: post.courseheading,
            overview: post.courseoverview,
            cardtopic: post.coursecontenttopic,
            cardsubtopic: post.coursecontentsubtopic
        });
    });

});

app.listen(process.env.PORT || 1000, function() {
    console.log("server is running successfully on port made by om kadam");
})